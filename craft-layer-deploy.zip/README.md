# CRAFT LAYER deployment preview

This folder is a self-contained browser preview for Vercel Drop.

Open https://vercel.com/drop and upload this ZIP.

The preview includes the CRAFT LAYER storefront, responsive design, collection filters, configurable product data in browser storage, a merchant preview, and product creation/deletion for demonstration.

The full production e-commerce backend still requires hosted PostgreSQL, authentication, server-side orders/inventory, payment credentials and webhooks, object storage, shipping integrations, and automated tests.
